See the comments in sample_app.cpp source file for usage.

